package com.example.baritoneui.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public final class KeyBindings {
	public static final String CATEGORY = "key.categories.baritoneui";

	public static final KeyMapping OPEN = new KeyMapping("key.baritoneui.open",
		InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, CATEGORY);
	public static final KeyMapping TOGGLE_MLG = new KeyMapping("key.baritoneui.mlg",
		InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, CATEGORY);
	public static final KeyMapping PANIC = new KeyMapping("key.baritoneui.cancel",
		InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_X, CATEGORY);

	private KeyBindings() {}
}
