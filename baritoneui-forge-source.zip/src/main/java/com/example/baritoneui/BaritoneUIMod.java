package com.example.baritoneui;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(BaritoneUIMod.MOD_ID)
public class BaritoneUIMod {
	public static final String MOD_ID = "baritoneui";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public BaritoneUIMod() {
		if (FMLEnvironment.dist == Dist.CLIENT) {
			LOGGER.info("Baritone UI charge (client).");
		}
	}
}
