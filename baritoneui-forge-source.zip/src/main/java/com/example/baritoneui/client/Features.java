package com.example.baritoneui.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

/** Fonctions client independantes de Baritone : MLG, manger, respawn. */
public final class Features {
	public static boolean autoMlg = true;
	public static boolean autoEat = false;
	public static boolean autoRespawn = true;
	/** Seuil de faim (sur 20) en dessous duquel on mange. */
	public static int eatBelow = 14;

	private static boolean eating;
	private static int eatPreviousSlot = -1;

	private Features() {}

	public static void tick(Minecraft mc, LocalPlayer p) {
		if (autoRespawn && mc.screen instanceof DeathScreen && p.isDeadOrDying()) {
			p.respawn();
			mc.setScreen(null);
			return;
		}
		if (p.isDeadOrDying()) {
			return;
		}

		boolean mlgBusy = false;
		if (autoMlg && !eating) {
			mlgBusy = PlayerMlg.tick(mc, p);
		} else if (!autoMlg && PlayerMlg.isBusy()) {
			PlayerMlg.reset();
		}

		if (autoEat && !mlgBusy) {
			tickEat(mc, p);
		} else if (eating) {
			stopEating(mc, p);
		}
	}

	private static void tickEat(Minecraft mc, LocalPlayer p) {
		if (eating) {
			boolean full = p.getFoodData().getFoodLevel() >= 20;
			if (full || !p.isUsingItem()) {
				stopEating(mc, p);
			} else {
				mc.options.keyUse.setDown(true);
			}
			return;
		}
		if (mc.screen != null || p.getFoodData().getFoodLevel() > eatBelow || p.isUsingItem()) {
			return;
		}
		int slot = findFood(p);
		if (slot < 0) {
			return;
		}
		eatPreviousSlot = p.getInventory().selected;
		p.getInventory().selected = slot;
		if (mc.gameMode != null && mc.gameMode.useItem(p, InteractionHand.MAIN_HAND).consumesAction()) {
			eating = true;
			mc.options.keyUse.setDown(true);
		} else {
			p.getInventory().selected = eatPreviousSlot;
			eatPreviousSlot = -1;
		}
	}

	private static void stopEating(Minecraft mc, LocalPlayer p) {
		mc.options.keyUse.setDown(false);
		if (eatPreviousSlot >= 0) {
			p.getInventory().selected = eatPreviousSlot;
		}
		eatPreviousSlot = -1;
		eating = false;
	}

	/** Premier aliment "sur" de la barre rapide (on evite pommes d'or, chair pourrie, poisson-globe...). */
	private static int findFood(LocalPlayer p) {
		for (int i = 0; i < 9; i++) {
			ItemStack s = p.getInventory().getItem(i);
			if (s.isEmpty() || !s.isEdible()) {
				continue;
			}
			String id = BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
			if (id.contains("golden_apple") || id.equals("rotten_flesh") || id.equals("spider_eye")
				|| id.equals("poisonous_potato") || id.equals("pufferfish") || id.equals("suspicious_stew")
				|| id.equals("chorus_fruit") || id.equals("enchanted_golden_apple")) {
				continue;
			}
			return i;
		}
		return -1;
	}
}
