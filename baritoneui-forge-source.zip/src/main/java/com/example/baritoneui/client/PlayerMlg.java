package com.example.baritoneui.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * MLG water pour TON joueur : en chute, regarde vers le bas, sort le seau d'eau,
 * pose l'eau au bon moment, puis la ramasse apres l'atterrissage.
 */
public final class PlayerMlg {
	private enum Phase { NONE, PLACED }

	private static Phase phase = Phase.NONE;
	private static int slot = -1;
	private static int previousSlot = -1;
	private static int landedTicks;
	private static int age;

	private PlayerMlg() {}

	public static boolean isBusy() {
		return phase != Phase.NONE || previousSlot >= 0;
	}

	public static void reset() {
		phase = Phase.NONE;
		slot = -1;
		previousSlot = -1;
		landedTicks = 0;
		age = 0;
	}

	/** @return true si le MLG a pris la main ce tick. */
	public static boolean tick(Minecraft mc, LocalPlayer p) {
		if (phase == Phase.PLACED) {
			return afterPlace(mc, p);
		}

		if (p.onGround() || p.isInWater() || p.isInLava() || p.getAbilities().flying || p.isFallFlying()
			|| p.isPassenger() || p.isSpectator() || p.getAbilities().instabuild) {
			if (previousSlot >= 0 && phase == Phase.NONE) {
				p.getInventory().selected = previousSlot;
				reset();
			}
			return false;
		}
		if (p.fallDistance < 2.0F && p.getDeltaMovement().y > -0.7) {
			return false;
		}

		int water = findHotbar(p, true);
		if (water < 0) {
			return false;
		}

		double ground = groundDistance(mc, p);
		if (ground < 0.0 || ground > 16.0) {
			return false; // vide, eau/lave dessous, ou encore tres haut
		}

		if (previousSlot < 0) {
			previousSlot = p.getInventory().selected;
		}
		p.getInventory().selected = water;
		p.setXRot(90.0F);

		if (ground <= 2.8 && mc.gameMode != null) {
			if (mc.gameMode.useItem(p, InteractionHand.MAIN_HAND).consumesAction()) {
				p.swing(InteractionHand.MAIN_HAND);
				slot = water;
				phase = Phase.PLACED;
				landedTicks = 0;
				age = 0;
			}
		}
		return true;
	}

	private static boolean afterPlace(Minecraft mc, LocalPlayer p) {
		age++;
		p.setXRot(90.0F);
		if (p.onGround() || p.isInWater()) {
			landedTicks++;
		}
		if (landedTicks >= 4 && landedTicks % 3 == 1 && mc.gameMode != null) {
			p.getInventory().selected = slot;
			ItemStack held = p.getInventory().getItem(slot);
			if (held.is(Items.BUCKET)) {
				mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
			}
		}
		boolean recovered = p.getInventory().getItem(slot).is(Items.WATER_BUCKET) && landedTicks >= 4;
		if (recovered || age > 80) {
			if (previousSlot >= 0) {
				p.getInventory().selected = previousSlot;
			}
			reset();
			return false;
		}
		return true;
	}

	/** Distance pied -> sol, ou -1 si on tomberait dans l'eau, la lave ou le vide. */
	private static double groundDistance(Minecraft mc, LocalPlayer p) {
		Vec3 from = p.position();
		Vec3 to = from.add(0.0, -40.0, 0.0);
		BlockHitResult hit = mc.level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.ANY, p));
		if (hit.getType() == HitResult.Type.MISS) {
			return -1.0;
		}
		var fluid = mc.level.getFluidState(hit.getBlockPos());
		if (fluid.is(FluidTags.WATER) || fluid.is(FluidTags.LAVA)) {
			return -1.0;
		}
		return from.y - hit.getLocation().y;
	}

	private static int findHotbar(LocalPlayer p, boolean waterBucket) {
		for (int i = 0; i < 9; i++) {
			ItemStack s = p.getInventory().getItem(i);
			if (waterBucket ? s.is(Items.WATER_BUCKET) : s.is(Items.BUCKET)) {
				return i;
			}
		}
		return -1;
	}
}
