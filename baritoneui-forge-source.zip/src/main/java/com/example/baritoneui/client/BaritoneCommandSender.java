package com.example.baritoneui.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;

/** Envoie une commande Baritone comme si tu la tapais dans le chat avec le prefixe # . */
public final class BaritoneCommandSender {
	public static final String PREFIX = "#";

	private BaritoneCommandSender() {}

	public static void send(String command) {
		LocalPlayer player = Minecraft.getInstance().player;
		if (player == null || command == null || command.isBlank()) {
			return;
		}
		String text = command.startsWith(PREFIX) ? command : PREFIX + command;
		player.connection.sendChat(text);
	}

	public static void info(String message) {
		LocalPlayer player = Minecraft.getInstance().player;
		if (player != null) {
			player.displayClientMessage(Component.literal(message), true);
		}
	}
}
