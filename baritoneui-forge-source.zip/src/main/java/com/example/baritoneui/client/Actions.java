package com.example.baritoneui.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Toutes les actions du panneau, rangees par onglet. */
public final class Actions {
	public enum Tab {
		NAV("Navigation"), MINE("Minage"), BUILD("Build/Ferme"), SETTINGS("Réglages"), SURVIVAL("Survie"), SPEEDRUN("Speedrun");

		public final String label;

		Tab(String label) {
			this.label = label;
		}
	}

	public enum Kind {
		/** Envoie une commande Baritone. %s est remplace par le champ "arguments". */
		COMMAND,
		/** Bascule un reglage Baritone : set <nom> true/false. */
		TOGGLE,
		/** Bascule une fonction client (MLG, manger, respawn). */
		CLIENT
	}

	public record Action(Kind kind, String label, String value, boolean defaultOn) {
		public boolean needsArgs() {
			return kind == Kind.COMMAND && value.contains("%s");
		}
	}

	/** Etat local des bascules (valeurs par defaut de Baritone, modifiables ici). */
	public static final Map<String, Boolean> TOGGLE_STATE = new HashMap<>();
	private static final Map<Tab, List<Action>> BY_TAB = new HashMap<>();

	public static List<Action> of(Tab tab) {
		return BY_TAB.getOrDefault(tab, List.of());
	}

	public static boolean state(Action a) {
		return TOGGLE_STATE.getOrDefault(a.value(), a.defaultOn());
	}

	private static void cmd(Tab t, String label, String command) {
		BY_TAB.computeIfAbsent(t, k -> new ArrayList<>()).add(new Action(Kind.COMMAND, label, command, false));
	}

	private static void toggle(Tab t, String label, String setting, boolean def) {
		BY_TAB.computeIfAbsent(t, k -> new ArrayList<>()).add(new Action(Kind.TOGGLE, label, setting, def));
	}

	private static void client(Tab t, String label, String id) {
		BY_TAB.computeIfAbsent(t, k -> new ArrayList<>()).add(new Action(Kind.CLIENT, label, id, false));
	}

	static {
		// ---------------- Navigation
		Tab n = Tab.NAV;
		cmd(n, "Goto X Y Z", "goto %s");
		cmd(n, "Goal X Y Z", "goal %s");
		cmd(n, "Goal ici", "goal");
		cmd(n, "Lancer le chemin", "path");
		cmd(n, "Viens ici", "come");
		cmd(n, "Surface", "surface");
		cmd(n, "Thisway 100", "thisway 100");
		cmd(n, "Thisway N", "thisway %s");
		cmd(n, "Axe (X/Z)", "axis");
		cmd(n, "Follow joueur", "follow player %s");
		cmd(n, "Follow entité", "follow entity %s");
		cmd(n, "Follow joueurs", "follow players");
		cmd(n, "Follow entités", "follow entities");
		cmd(n, "Explorer", "explore");
		cmd(n, "Explorer X Z", "explore %s");
		cmd(n, "Filtre explore", "explorefilter %s");
		cmd(n, "Goto table craft", "goto crafting_table");
		cmd(n, "Goto four", "goto furnace");
		cmd(n, "Goto coffre", "goto chest");
		cmd(n, "Goto lit", "goto bed");
		cmd(n, "Goto portail", "goto nether_portal");
		cmd(n, "Goto eau", "goto water");
		cmd(n, "Pause", "pause");
		cmd(n, "Reprendre", "resume");
		cmd(n, "ETA", "eta");
		cmd(n, "ANNULER", "cancel");

		// ---------------- Minage
		Tab m = Tab.MINE;
		cmd(m, "Miner (bloc)", "mine %s");
		cmd(m, "Diamant", "mine diamond_ore deepslate_diamond_ore");
		cmd(m, "Fer", "mine iron_ore deepslate_iron_ore");
		cmd(m, "Charbon", "mine coal_ore deepslate_coal_ore");
		cmd(m, "Or", "mine gold_ore deepslate_gold_ore nether_gold_ore");
		cmd(m, "Redstone", "mine redstone_ore deepslate_redstone_ore");
		cmd(m, "Lapis", "mine lapis_ore deepslate_lapis_ore");
		cmd(m, "Émeraude", "mine emerald_ore deepslate_emerald_ore");
		cmd(m, "Cuivre", "mine copper_ore deepslate_copper_ore");
		cmd(m, "Débris antiques", "mine ancient_debris");
		cmd(m, "Quartz", "mine nether_quartz_ore");
		cmd(m, "Obsidienne", "mine obsidian");
		cmd(m, "Bois (chene)", "mine oak_log");
		cmd(m, "Bois (tous)", "mine oak_log birch_log spruce_log jungle_log acacia_log dark_oak_log mangrove_log");
		cmd(m, "Pierre", "mine stone");
		cmd(m, "Sable", "mine sand");
		cmd(m, "Gravier", "mine gravel");
		cmd(m, "Glowstone", "mine glowstone");
		cmd(m, "Netherrack", "mine netherrack");
		cmd(m, "Tunnel", "tunnel");
		cmd(m, "Tunnel H L D", "tunnel %s");
		cmd(m, "Chercher bloc", "find %s");
		cmd(m, "Liste noire", "blacklist");
		cmd(m, "Clic (cible)", "click");
		cmd(m, "ANNULER", "cancel");

		// ---------------- Build / ferme
		Tab b = Tab.BUILD;
		cmd(b, "Ferme", "farm");
		cmd(b, "Ferme (rayon)", "farm %s");
		cmd(b, "Build (fichier)", "build %s");
		cmd(b, "Build ici", "build %s ~ ~ ~");
		cmd(b, "Sel : point 1", "sel pos1");
		cmd(b, "Sel : point 2", "sel pos2");
		cmd(b, "Sel : effacer", "sel clear");
		cmd(b, "Sel : annuler", "sel undo");
		cmd(b, "Sel : remplir", "sel set %s");
		cmd(b, "Sel : murs", "sel walls %s");
		cmd(b, "Sel : coque", "sel shell %s");
		cmd(b, "Sel : sphère", "sel sphere %s");
		cmd(b, "Sel : cylindre", "sel cyl %s");
		cmd(b, "Sel : vider zone", "sel cleararea");
		cmd(b, "Sel : copier", "sel copy");
		cmd(b, "Sel : coller", "sel paste");
		cmd(b, "Sel : remplacer", "sel replace %s");
		cmd(b, "ANNULER", "cancel");

		// ---------------- Reglages (valeurs par defaut de Baritone)
		Tab s = Tab.SETTINGS;
		toggle(s, "Casser blocs", "allowBreak", true);
		toggle(s, "Poser blocs", "allowPlace", true);
		toggle(s, "Parkour", "allowParkour", false);
		toggle(s, "Parkour + blocs", "allowParkourPlace", false);
		toggle(s, "Sprint", "allowSprint", true);
		toggle(s, "Descendre", "allowDownward", true);
		toggle(s, "Inventaire", "allowInventory", false);
		toggle(s, "Outil auto", "autoTool", true);
		toggle(s, "Minage légal", "legitMine", false);
		toggle(s, "MLG eau (seau)", "allowWaterBucketFall", true);
		toggle(s, "Build par couches", "buildInLayers", false);
		toggle(s, "Caméra libre", "freeLook", true);
		toggle(s, "Marcher sur eau", "assumeWalkOnWater", false);
		toggle(s, "Saut en y=256", "allowJumpAt256", false);
		toggle(s, "Ramasser drops", "mineScanDroppedItems", true);
		toggle(s, "Remblayer", "backfill", false);
		toggle(s, "Éviter mobs", "avoidance", false);
		toggle(s, "Afficher chemin", "renderPath", true);
		toggle(s, "Afficher but", "renderGoal", true);
		toggle(s, "Économiser objets", "itemSaver", false);
		toggle(s, "Minerais visibles", "allowOnlyExposedOres", false);
		toggle(s, "Mode map art", "mapArtMode", false);
		toggle(s, "Contrôle chat", "chatControl", true);
		cmd(s, "Réglage = valeur", "set %s");
		cmd(s, "Chute max seau 25", "set maxFallHeightBucket 25");
		cmd(s, "Chute max sans eau 3", "set maxFallHeightNoWater 3");
		cmd(s, "Reset réglages", "set reset");
		cmd(s, "Liste réglages", "set");

		// ---------------- Survie (fonctions client)
		Tab v = Tab.SURVIVAL;
		client(v, "MLG auto (joueur)", "mlg");
		client(v, "Manger auto", "eat");
		client(v, "Respawn auto", "respawn");
		cmd(v, "Sauver (save)", "save");
		cmd(v, "Reboot Baritone", "reloadall");
		cmd(v, "Version", "version");
		cmd(v, "Aide", "help");
		cmd(v, "Proc (processus)", "proc");
		cmd(v, "Repack chunks", "repack");
		cmd(v, "ANNULER", "cancel");
	}

	private Actions() {}
}
