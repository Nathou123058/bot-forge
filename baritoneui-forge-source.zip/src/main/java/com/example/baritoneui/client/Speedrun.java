package com.example.baritoneui.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.function.Predicate;

/**
 * Checklist "finir le jeu". Chaque etape envoie sa commande Baritone ; en mode auto,
 * on passe a la suivante des que l'inventaire / la dimension montre que l'etape est faite.
 * Baritone ne sait pas crafter : les etapes (manuel) attendent que TU fasses l'objet.
 */
public final class Speedrun {
	public record Step(String title, String command, boolean manual, Predicate<LocalPlayer> done) {}

	public static final List<Step> STEPS = List.of(
		new Step("Bois (16 bûches)", "mine 16 oak_log birch_log spruce_log jungle_log acacia_log dark_oak_log", false,
			p -> countEnding(p, "_log") >= 12),
		new Step("Table + bâtons + pioche en bois", null, true,
			p -> hasPickaxe(p, "wooden", "stone", "iron", "diamond", "netherite")),
		new Step("Pierre (24 cobblestone)", "mine 24 stone", false,
			p -> count(p, "cobblestone") >= 20),
		new Step("Pioche en pierre + four", null, true,
			p -> hasPickaxe(p, "stone", "iron", "diamond", "netherite")),
		new Step("Charbon (8)", "mine 12 coal_ore deepslate_coal_ore", false,
			p -> count(p, "coal") + count(p, "charcoal") >= 8),
		new Step("Fer (12 minerais)", "mine 14 iron_ore deepslate_iron_ore", false,
			p -> count(p, "raw_iron") + count(p, "iron_ingot") >= 12),
		new Step("Fondre le fer", null, true,
			p -> count(p, "iron_ingot") >= 11),
		new Step("Pioche en fer + seau + briquet", null, true,
			p -> hasPickaxe(p, "iron", "diamond", "netherite") && count(p, "bucket") + count(p, "water_bucket") >= 1),
		new Step("Diamants (3+)", "mine 4 diamond_ore deepslate_diamond_ore", false,
			p -> count(p, "diamond") >= 3 || hasPickaxe(p, "diamond", "netherite")),
		new Step("Pioche en diamant", null, true,
			p -> hasPickaxe(p, "diamond", "netherite")),
		new Step("Obsidienne (10)", "mine 10 obsidian", false,
			p -> count(p, "obsidian") >= 10 || inDimension(p, Level.NETHER)),
		new Step("Portail + entrer dans le Nether", null, true,
			p -> inDimension(p, Level.NETHER)),
		new Step("Explorer le Nether : forteresse, 7 blaze rods", "explore", false,
			p -> count(p, "blaze_rod") + count(p, "blaze_powder") >= 7),
		new Step("Perles d'ender (12)", null, true,
			p -> count(p, "ender_pearl") + count(p, "ender_eye") >= 12),
		new Step("Yeux d'ender (12)", null, true,
			p -> count(p, "ender_eye") >= 12),
		new Step("Forteresse du monde : lancer les yeux, portail de l'End", null, true,
			p -> inDimension(p, Level.END)),
		new Step("Tuer le dragon !", null, true,
			p -> false)
	);

	public static boolean auto = false;
	public static int step = 0;
	private static int timer;

	private Speedrun() {}

	public static Step current() {
		return STEPS.get(Math.min(step, STEPS.size() - 1));
	}

	public static void start(int index) {
		step = Math.max(0, Math.min(index, STEPS.size() - 1));
		BaritoneCommandSender.send("cancel");
		Step s = current();
		if (s.command() != null) {
			BaritoneCommandSender.send(s.command());
		}
		BaritoneCommandSender.info("§b[Speedrun " + (step + 1) + "/" + STEPS.size() + "] " + s.title()
			+ (s.manual() ? " §7(manuel)" : ""));
	}

	public static void tick(Minecraft mc, LocalPlayer p) {
		if (!auto) {
			return;
		}
		if (++timer < 20) {
			return;
		}
		timer = 0;
		if (step < STEPS.size() - 1 && current().done().test(p)) {
			start(step + 1);
		}
	}

	// ------------------------------------------------------------------ inventaire

	static int count(LocalPlayer p, String path) {
		return sum(p, id -> id.equals(path));
	}

	static int countEnding(LocalPlayer p, String suffix) {
		return sum(p, id -> id.endsWith(suffix));
	}

	private static boolean hasPickaxe(LocalPlayer p, String... tiers) {
		for (String tier : tiers) {
			if (count(p, tier + "_pickaxe") > 0) {
				return true;
			}
		}
		return false;
	}

	private static boolean inDimension(LocalPlayer p, net.minecraft.resources.ResourceKey<Level> dim) {
		return p.level().dimension() == dim;
	}

	private static int sum(LocalPlayer p, Predicate<String> match) {
		int n = 0;
		for (ItemStack s : p.getInventory().items) {
			if (!s.isEmpty() && match.test(BuiltInRegistries.ITEM.getKey(s.getItem()).getPath())) {
				n += s.getCount();
			}
		}
		for (ItemStack s : p.getInventory().offhand) {
			if (!s.isEmpty() && match.test(BuiltInRegistries.ITEM.getKey(s.getItem()).getPath())) {
				n += s.getCount();
			}
		}
		return n;
	}
}
