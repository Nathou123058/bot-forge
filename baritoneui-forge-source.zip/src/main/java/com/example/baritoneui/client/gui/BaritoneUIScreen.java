package com.example.baritoneui.client.gui;

import com.example.baritoneui.client.Actions;
import com.example.baritoneui.client.Actions.Action;
import com.example.baritoneui.client.Actions.Kind;
import com.example.baritoneui.client.Actions.Tab;
import com.example.baritoneui.client.BaritoneCommandSender;
import com.example.baritoneui.client.Features;
import com.example.baritoneui.client.Speedrun;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** Panneau a onglets pour piloter Baritone. */
public class BaritoneUIScreen extends Screen {
	private static Tab currentTab = Tab.NAV;
	private static int page = 0;
	private static String savedArgs = "";

	private EditBox argsBox;
	private EditBox freeBox;

	public BaritoneUIScreen() {
		super(Component.literal("Baritone UI"));
	}

	@Override
	protected void init() {
		Tab[] tabs = Tab.values();
		int tabW = (this.width - 20) / tabs.length;
		for (int i = 0; i < tabs.length; i++) {
			Tab tab = tabs[i];
			Button b = Button.builder(Component.literal(tab.label), btn -> {
				currentTab = tab;
				page = 0;
				this.rebuildWidgets();
			}).bounds(10 + i * tabW, 8, tabW - 2, 20).build();
			b.active = tab != currentTab;
			addRenderableWidget(b);
		}

		// Champs de saisie (bas de l'ecran)
		argsBox = new EditBox(this.font, 10, this.height - 52, this.width - 20, 18, Component.literal("Arguments"));
		argsBox.setMaxLength(200);
		argsBox.setValue(savedArgs);
		argsBox.setHint(Component.literal("Arguments (%s) : ex. 100 70 -200  |  diamond_ore  |  Steve"));
		addRenderableWidget(argsBox);

		freeBox = new EditBox(this.font, 10, this.height - 28, this.width - 100, 18, Component.literal("Commande"));
		freeBox.setMaxLength(256);
		freeBox.setHint(Component.literal("Commande libre Baritone (sans #) puis Entree"));
		addRenderableWidget(freeBox);
		addRenderableWidget(Button.builder(Component.literal("Envoyer"), b -> sendFree())
			.bounds(this.width - 86, this.height - 29, 76, 20).build());

		if (currentTab == Tab.SPEEDRUN) {
			initSpeedrun();
		} else {
			initActions();
		}
	}

	private void initActions() {
		List<Action> all = Actions.of(currentTab);
		int cols = Math.max(2, Math.min(5, (this.width - 20) / 108));
		int btnW = (this.width - 20 - (cols - 1) * 4) / cols;
		int top = 38;
		int rows = Math.max(1, (this.height - 52 - 8 - top) / 24);
		int perPage = cols * rows;
		int pages = Math.max(1, (all.size() + perPage - 1) / perPage);
		page = Math.min(page, pages - 1);

		for (int i = 0; i < perPage; i++) {
			int idx = page * perPage + i;
			if (idx >= all.size()) {
				break;
			}
			Action a = all.get(idx);
			int x = 10 + (i % cols) * (btnW + 4);
			int y = top + (i / cols) * 24;
			Button button = Button.builder(Component.literal(labelFor(a)), btn -> {
				run(a);
				btn.setMessage(Component.literal(labelFor(a)));
			}).bounds(x, y, btnW, 20).build();
			addRenderableWidget(button);
		}

		if (pages > 1) {
			int y = this.height - 76;
			addRenderableWidget(Button.builder(Component.literal("<"), b -> {
				page = (page - 1 + pages) % pages;
				this.rebuildWidgets();
			}).bounds(this.width / 2 - 50, y, 30, 18).build());
			addRenderableWidget(Button.builder(Component.literal(">"), b -> {
				page = (page + 1) % pages;
				this.rebuildWidgets();
			}).bounds(this.width / 2 + 20, y, 30, 18).build());
		}
	}

	private void initSpeedrun() {
		int cx = this.width / 2;
		int y = this.height - 100;
		addRenderableWidget(Button.builder(Component.literal("◀ Précédente"), b -> {
			Speedrun.start(Speedrun.step - 1);
			this.rebuildWidgets();
		}).bounds(cx - 205, y, 100, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Renvoyer"), b -> Speedrun.start(Speedrun.step))
			.bounds(cx - 101, y, 100, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Suivante ▶"), b -> {
			Speedrun.start(Speedrun.step + 1);
			this.rebuildWidgets();
		}).bounds(cx + 3, y, 100, 20).build());
		addRenderableWidget(Button.builder(Component.literal(autoLabel()), b -> {
			Speedrun.auto = !Speedrun.auto;
			if (Speedrun.auto) {
				Speedrun.start(Speedrun.step);
			}
			b.setMessage(Component.literal(autoLabel()));
		}).bounds(cx + 107, y, 100, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Recommencer (1)"), b -> {
			Speedrun.start(0);
			this.rebuildWidgets();
		}).bounds(cx - 100, y - 24, 200, 20).build());
	}

	private static String autoLabel() {
		return "Auto : " + (Speedrun.auto ? "§aON" : "§cOFF");
	}

	private static String labelFor(Action a) {
		return switch (a.kind()) {
			case TOGGLE -> a.label() + " : " + (Actions.state(a) ? "§aON" : "§cOFF");
			case CLIENT -> a.label() + " : " + (clientState(a.value()) ? "§aON" : "§cOFF");
			default -> a.label();
		};
	}

	private static boolean clientState(String id) {
		return switch (id) {
			case "mlg" -> Features.autoMlg;
			case "eat" -> Features.autoEat;
			case "respawn" -> Features.autoRespawn;
			default -> false;
		};
	}

	private void run(Action a) {
		savedArgs = argsBox.getValue();
		switch (a.kind()) {
			case COMMAND -> {
				String args = argsBox.getValue().trim();
				if (a.needsArgs() && args.isEmpty()) {
					BaritoneCommandSender.info("§c[Baritone UI] Remplis le champ Arguments d'abord.");
					return;
				}
				BaritoneCommandSender.send(a.value().replace("%s", args).trim());
			}
			case TOGGLE -> {
				boolean next = !Actions.state(a);
				Actions.TOGGLE_STATE.put(a.value(), next);
				BaritoneCommandSender.send("set " + a.value() + " " + next);
			}
			case CLIENT -> {
				switch (a.value()) {
					case "mlg" -> Features.autoMlg = !Features.autoMlg;
					case "eat" -> Features.autoEat = !Features.autoEat;
					case "respawn" -> Features.autoRespawn = !Features.autoRespawn;
					default -> { }
				}
			}
		}
	}

	private void sendFree() {
		String text = freeBox.getValue().trim();
		if (!text.isEmpty()) {
			BaritoneCommandSender.send(text);
			freeBox.setValue("");
		}
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (freeBox != null && freeBox.isFocused()
			&& (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
			sendFree();
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public void onClose() {
		if (argsBox != null) {
			savedArgs = argsBox.getValue();
		}
		super.onClose();
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		this.renderBackground(g);
		if (currentTab == Tab.SPEEDRUN) {
			renderSpeedrun(g);
		}
		super.render(g, mouseX, mouseY, partialTick);
	}

	private void renderSpeedrun(GuiGraphics g) {
		var player = Minecraft.getInstance().player;
		int x = 14;
		int y = 38;
		int lineH = 11;
		int maxLines = Math.max(3, (this.height - 150 - y) / lineH);
		int first = Math.max(0, Math.min(Speedrun.step - maxLines / 2, Speedrun.STEPS.size() - maxLines));
		for (int i = first; i < Math.min(Speedrun.STEPS.size(), first + maxLines); i++) {
			var s = Speedrun.STEPS.get(i);
			boolean done = player != null && i < Speedrun.step;
			boolean current = i == Speedrun.step;
			String prefix = done ? "§a✔ " : current ? "§e▶ " : "§7  ";
			String tag = s.manual() ? " §8(manuel)" : "";
			g.drawString(this.font, prefix + (i + 1) + ". " + s.title() + tag, x, y + (i - first) * lineH,
				current ? 0xFFFFFF : 0xAAAAAA);
		}
		var cur = Speedrun.current();
		g.drawString(this.font, "§bCommande : §f" + (cur.command() == null ? "(aucune, fais-le toi-même)" : "#" + cur.command()),
			x, this.height - 128, 0xFFFFFF);
	}
}
