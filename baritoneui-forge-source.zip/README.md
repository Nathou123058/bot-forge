# Baritone UI (Forge 1.20.1)

Panneau a onglets pour piloter Baritone (embarque dans le jar) + MLG auto, manger auto, respawn auto et checklist "finir le jeu".

- Touche **B** : ouvrir le panneau | **X** : annuler Baritone (urgence) | MLG : touche a assigner dans Controles > Baritone UI
- 100+ actions : Navigation, Minage, Build/Ferme, Reglages, Survie, Speedrun + champ de commande libre.
- Champ "Arguments" : remplace %s (ex. `100 70 -200` pour Goto X Y Z, `diamond_ore` pour Miner).

## Obtenir le .jar
1. Mets tout ce dossier dans un depot GitHub public.
2. Onglet Actions > build > Artifacts > `baritoneui-jar`.
3. Copie le .jar dans `mods/` (Forge 1.20.1, 47.x).

Baritone ne sait pas crafter : les etapes "(manuel)" du Speedrun attendent que tu fabriques l'objet.
