package com.example.baritoneui.client;

import com.example.baritoneui.BaritoneUIMod;
import com.example.baritoneui.client.gui.BaritoneUIScreen;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public final class ClientEvents {
	private ClientEvents() {}

	@Mod.EventBusSubscriber(modid = BaritoneUIMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static final class ModBus {
		@SubscribeEvent
		public static void registerKeys(RegisterKeyMappingsEvent event) {
			event.register(KeyBindings.OPEN);
			event.register(KeyBindings.TOGGLE_MLG);
			event.register(KeyBindings.PANIC);
		}
	}

	@Mod.EventBusSubscriber(modid = BaritoneUIMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
	public static final class ForgeBus {
		@SubscribeEvent
		public static void onClientTick(TickEvent.ClientTickEvent event) {
			if (event.phase != TickEvent.Phase.START) {
				return;
			}
			Minecraft mc = Minecraft.getInstance();

			while (KeyBindings.OPEN.consumeClick()) {
				if (mc.player != null && mc.screen == null) {
					mc.setScreen(new BaritoneUIScreen());
				}
			}
			while (KeyBindings.TOGGLE_MLG.consumeClick()) {
				Features.autoMlg = !Features.autoMlg;
				BaritoneCommandSender.info("Auto MLG : " + (Features.autoMlg ? "§aON" : "§cOFF"));
			}
			while (KeyBindings.PANIC.consumeClick()) {
				BaritoneCommandSender.send("cancel");
				Speedrun.auto = false;
				BaritoneCommandSender.info("§c[Baritone UI] Annule + auto-speedrun stoppe");
			}

			if (mc.player == null || mc.level == null) {
				PlayerMlg.reset();
				return;
			}
			Features.tick(mc, mc.player);
			Speedrun.tick(mc, mc.player);
		}
	}
}
